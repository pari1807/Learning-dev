// Server.js: initialize production scheduler charts

document.addEventListener('DOMContentLoaded', () => {
  // Initialize charts
  initProductionCharts();
  // Trigger CSS transitions
  setTimeout(() => {
    document.querySelectorAll('.chart-card').forEach(card => card.classList.add('visible'));
  }, 50);
});

function initProductionCharts() {
  // Disable Chart.js animations for faster rendering
  Chart.defaults.animation.duration = 0;
  // Chart.js defaults
  Chart.defaults.font.family = "'Poppins', sans-serif";
  Chart.defaults.font.size = 14;
  Chart.defaults.animation.easing = 'easeOutQuart';
  Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(30, 41, 59, 0.8)';

  // Completion Status Doughnut
  new Chart(document.getElementById('completionChart'), {
    type: 'doughnut',
    data: { labels: ['Completed','In Progress','Pending'], datasets: [{ data: [70,20,10], backgroundColor: ['#8B5CF6','#C084FC','#E9D5FF'], hoverOffset: 15 }] },
    options: { cutout: '70%', plugins: { legend: { position: 'bottom' } }, responsive: true, maintainAspectRatio: false }
  });

  // Machine Utilization Bar
  new Chart(document.getElementById('machineChart'), {
    type: 'bar',
    data: { labels: ['M1','M2','M3','M4'], datasets: [{ label: 'Utilization %', data: [85,75,60,90], backgroundColor: ['#8B5CF6','#EC4899','#3B82F6','#F97316'], borderRadius: 8 }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } }
  });

  // Throughput Trend Line
  new Chart(document.getElementById('throughputChart'), {
    type: 'line',
    data: { labels: ['Shift 1','Shift 2','Shift 3','Shift 4'], datasets: [{ label: 'Units Produced', data: [120,150,110,170], borderColor: '#9333EA', backgroundColor: 'rgba(147,51,234,0.1)', fill: true, tension: 0.3 }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true } }, plugins: { legend: { display: false } } }
  });

  // Backlog Composition Polar Area
  new Chart(document.getElementById('backlogChart'), {
    type: 'polarArea',
    data: { labels: ['High Pri','Medium Pri','Low Pri'], datasets: [{ data: [30,45,25], backgroundColor: ['#8B5CF6','#EC4899','#3B82F6'] }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
  });

  // Worker Availability Radar
  new Chart(document.getElementById('availabilityChart'), {
    type: 'radar',
    data: { labels: ['Team A','Team B','Team C','Team D','Team E'], datasets: [{ label: 'Avail %', data: [90,80,70,85,75], backgroundColor: 'rgba(139,92,246,0.2)', borderColor: '#8B5CF6' }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { r: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } }
  });

  // Supply Levels Radar
  new Chart(document.getElementById('supplyChart'), {
    type: 'radar',
    data: { labels: ['Steel','Plastic','Electronics','Packaging','Chemicals'], datasets: [{ label: 'Stock %', data: [50,65,80,40,75], backgroundColor: 'rgba(236,72,153,0.2)', borderColor: '#EC4899' }] },
    options: { responsive: true, maintainAspectRatio: false, scales: { r: { beginAtZero: true, max: 100 } }, plugins: { legend: { display: false } } }
  });
}